# Mayur Jadhav — Portfolio

A responsive, single-page personal portfolio for Mayur Jadhav, a second-year B.Tech Computer Science and Engineering student specializing in Artificial Intelligence and Machine Learning at Sandip University, Nashik, Maharashtra, India.

The page is deliberately honest about what is not yet supplied: project cards are clearly marked as suggested examples, skills are prompts to customize, and no employment, award, certification, social URL, or email has been invented. Resume downloads stay disabled until a real PDF is added.

## Features

- Single-page portfolio with introduction, about, skills, project ideas, education, achievements, certifications, experience, resume, contact, and footer sections.
- Responsive navigation, including a collapsible mobile menu and skip-to-content link.
- Light and dark theme toggle with a remembered preference when browser storage is available.
- Interactive skill-category tabs and project filters.
- Keyboard-visible focus states, semantic landmarks, accessible labels, and reduced-motion support.
- No backend, database, API, credential, or contact form dependency.

## Stack

- React + TypeScript
- Vite
- CSS with custom properties and Tailwind CSS v4 scaffold integration
- Lucide icons

## Run locally

From this directory:

```sh
npm install
npm run dev
```

Build and type-check:

```sh
npm run typecheck
npm run build
```

## Folder structure

```text
.
├── public/
│   └── assets/           # Add a real resume PDF here when ready
├── src/
│   ├── App.tsx           # Page content and interactive controls
│   ├── index.css         # Theme, layout, responsive styles, motion
│   └── main.tsx          # Vite/React entry point
├── index.html
├── package.json
└── vite.config.ts
```

## Personalize before publishing

1. **Skills:** In `src/App.tsx`, update the `skillGroups` entries with languages, tools, and concepts Mayur has genuinely used. The listed items are editable suggestions from the brief; remove anything that is not accurate.
2. **Projects:** The three project titles are suggestions only, not claims of completed work. In `projects`, replace or remove them after verifying the actual project, approach, stack, and current status. The cards include screenshot and link placeholders; add verified images and exact public repository/demo URLs only when available.
3. **Achievements and certifications:** Replace the empty-state copy with real names, dates, providers, and verification links where available.
4. **Experience:** Add only verified roles, organizations, dates, and responsibilities.
5. **Contact and socials:** Replace the contact prompts with a public email address or exact social URLs that Mayur has confirmed. The current page intentionally contains no fake links or nonfunctional form.
6. **Resume:** Put the verified PDF at `public/assets/resume.pdf`. Then change the disabled button in `src/App.tsx` into a normal link pointing to `/assets/resume.pdf` and update its accessible label and availability copy. Do not enable the download before the file exists.
7. **Profile image / screenshots:** No portrait or screenshot is included because none was supplied. The About section has an initials placeholder; replace it with a portrait from `public/assets/profile.jpg` only with permission and useful alternative text. To add project screenshots, place verified images in `public/assets/projects/`, use local paths in each project card, and provide useful alternative text.
8. **Metadata:** Update the page title and description in `index.html` if the public title or summary changes.

## Deploy to Vercel

1. Push the project repository to GitHub.
2. Import the repository in Vercel and keep the repository root as the Root Directory so it can read the pnpm workspace.
3. The root `vercel.json` sets the install command, portfolio build command, and static output directory.
4. Deploy. This is a static frontend and does not need server environment variables.

Before sharing the public site, replace the content prompts with verified personal information, test the theme/menu/filter controls on a phone, and confirm every newly added URL and resume file.
