import { useEffect, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  ArrowUpRight,
  Award,
  BookOpen,
  BriefcaseBusiness,
  Code2,
  Download,
  Mail,
  MapPin,
  Menu,
  Moon,
  Sparkles,
  Sun,
  X,
} from 'lucide-react';

const navigation = [
  ['About', '#about'],
  ['Skills', '#skills'],
  ['Projects', '#projects'],
  ['Journey', '#journey'],
  ['Contact', '#contact'],
];

const skillGroups = [
  {
    label: 'Languages',
    count: '01',
    title: 'Languages',
    description: 'Editable suggestions from the brief. Confirm which languages you have actually used before publishing.',
    examples: ['Python', 'C'],
  },
  {
    label: 'AI / ML',
    count: '02',
    title: 'AI & machine learning',
    description: 'Editable study areas from the brief. Add only concepts, libraries, or coursework you have personally explored.',
    examples: ['Artificial intelligence', 'Machine learning'],
  },
  {
    label: 'Web',
    count: '03',
    title: 'Web development',
    description: 'Editable technology suggestions from the brief. Keep only the tools you have personally tried.',
    examples: ['HTML', 'CSS', 'JavaScript', 'React'],
  },
  {
    label: 'Tools & ways of working',
    count: '04',
    title: 'Tools & ways of working',
    description: 'Editable tool suggestions from the brief. Keep only the tools and topics you have actually used.',
    examples: ['Git', 'GitHub', 'Databases'],
  },
];

const projects = [
  {
    category: 'AI / ML',
    title: 'Bayesian Student Predictor',
    summary:
      'Suggested idea only: explore a small sample dataset, build a simple Bayesian model, and explain its limits.',
    stack: ['Python', 'Bayesian methods', 'Data'],
    preview: 'A small model-results panel',
  },
  {
    category: 'Web',
    title: 'Sandip University Event Hub',
    summary:
      'Suggested idea only: a simple campus events directory with clear categories and a mobile-friendly layout.',
    stack: ['HTML / CSS', 'JavaScript', 'Web app'],
    preview: 'A campus events list',
  },
  {
    category: 'AI / ML',
    title: 'Rule-Based Medical Diagnosis Expert System',
    summary:
      'Suggested idea only: organize sample symptoms and rules to demonstrate how a basic expert system reaches a result.',
    stack: ['Python', 'Rule-based logic', 'Health education'],
    preview: 'A rule-flow diagram',
  },
];

function App() {
  const [dark, setDark] = useState(() => {
    try {
      return localStorage.getItem('mayur-theme') !== 'light';
    } catch {
      return true;
    }
  });
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSkill, setActiveSkill] = useState(0);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
    try {
      localStorage.setItem('mayur-theme', dark ? 'dark' : 'light');
    } catch {
      // Theme still works for this session when storage is unavailable.
    }
  }, [dark]);

  const visibleProjects = projects.filter((project) => filter === 'All' || project.category === filter);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="portfolio-shell">
      <a className="skip-link" href="#main-content">Skip to content</a>
      <header className="site-header">
        <div className="container header-inner">
          <a href="#top" className="brand" aria-label="Mayur Jadhav, home" data-testid="link-home">
            <span className="brand-mark">MJ</span>
            <span>Mayur Jadhav</span>
          </a>
          <nav className="nav-links" aria-label="Main navigation">
            {navigation.map(([label, href]) => <a href={href} key={href}>{label}</a>)}
          </nav>
          <div className="header-actions">
            <button
              className="icon-button"
              type="button"
              onClick={() => setDark((value) => !value)}
              aria-label={`Switch to ${dark ? 'light' : 'dark'} theme`}
              title={`Switch to ${dark ? 'light' : 'dark'} theme`}
              data-testid="button-theme-toggle"
            >
              {dark ? <Sun size={17} /> : <Moon size={17} />}
            </button>
            <a className="button" href="#contact">Say hello <ArrowUpRight size={15} /></a>
            <button
              className="menu-button"
              type="button"
              aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen((value) => !value)}
              data-testid="button-mobile-menu"
            >
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
          {menuOpen && (
            <nav className="mobile-panel" aria-label="Mobile navigation">
              {navigation.map(([label, href]) => (
                <a key={href} href={href} onClick={closeMenu}>{label}</a>
              ))}
              <a href="#resume" onClick={closeMenu}>Resume status</a>
            </nav>
          )}
        </div>
      </header>

      <main id="main-content">
        <section className="hero" id="top" aria-labelledby="hero-title">
          <div className="container hero-grid">
            <div className="reveal">
              <div className="hero-kicker"><span className="status-dot" /> Student · curious by default</div>
              <h1 className="display" id="hero-title">Learning to build<br />what comes <span>next.</span></h1>
              <p className="hero-copy">
                I’m Mayur Jadhav, a second-year Computer Science and Engineering student
                specializing in Artificial Intelligence and Machine Learning. I’m building
                my foundations one question, experiment, and project at a time.
              </p>
              <div className="hero-cta">
                <a className="button" href="#projects">Explore project ideas <ArrowDown size={15} /></a>
                <a className="button secondary" href="#about">A little about me <ArrowLeft size={15} /></a>
              </div>
              <div className="hero-location"><MapPin size={14} /> Sandip University · Nashik, Maharashtra, India</div>
            </div>
            <div className="visual-stage" aria-label="A small code card illustrating curiosity and learning">
              <div className="orbit"><span className="orbit-node" /></div>
              <div className="floating-tag one"><Sparkles className="tag-spark" size={12} /> learning in public</div>
              <div className="floating-tag two"><span className="tag-spark">↗</span> one idea at a time</div>
              <div className="code-card">
                <div className="code-top"><span className="window-dots"><i /><i /><i /></span><span>mayur / now.py</span><span>01:01</span></div>
                <div className="code-body" aria-label="Code-style profile note">
                  <div className="comment"># current chapter</div>
                  <div><span className="key">student</span> <span className="plain">=</span> <span className="value">"year two"</span></div>
                  <div><span className="key">focus</span> <span className="plain">=</span> <span className="value">"AI + ML"</span></div>
                  <div><span className="key">location</span> <span className="plain">=</span> <span className="value">"Nashik, IN"</span></div>
                  <br />
                  <div><span className="key">next_step</span> <span className="plain">=</span></div>
                  <div className="value">"keep learning, keep building"</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="about" aria-labelledby="about-title">
          <div className="container about-grid">
            <div>
              <div className="eyebrow">01 / A quick introduction</div>
              <h2 className="section-title display" id="about-title">Early in the journey.<br />All in on the learning.</h2>
              <div className="facts-row">
                <div className="fact"><strong>02</strong><span>Year of study</span></div>
                <div className="fact"><strong>CSE</strong><span>Degree</span></div>
                <div className="fact"><strong>AI + ML</strong><span>Specialization</span></div>
              </div>
            </div>
            <div>
              <p className="about-copy">
                I’m studying <strong>Computer Science and Engineering</strong> with a
                specialization in <strong>Artificial Intelligence and Machine Learning</strong>
                at Sandip University in Nashik. I’m still at the beginning of my developer
                story, which is exactly why I’m excited: there’s so much left to understand.
              </p>
              <p className="about-copy">
                This page is a living snapshot, not a claim to expertise. As I complete real
                coursework and projects, I’ll replace the prompts below with details I can
                confidently explain.
              </p>
              <div className="about-note">“The best way to understand an idea is to make something with it.”</div>
              <div className="profile-placeholder" aria-label="Profile photo placeholder">
                <span className="profile-initials" aria-hidden="true">MJ</span>
                <span><strong>Profile photo placeholder</strong><small>Replace with a real portrait when ready.</small></span>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="skills" aria-labelledby="skills-title">
          <div className="container">
            <div className="section-heading">
              <div><div className="eyebrow">02 / The toolkit</div><h2 className="section-title display" id="skills-title">Things I’m learning.</h2></div>
              <p className="section-intro">Editable suggestions from your brief—not a claim of expertise. Confirm each item and remove anything you have not used.</p>
            </div>
            <div className="skill-layout">
              <div className="skill-tabs" role="tablist" aria-label="Skill categories">
                {skillGroups.map((group, index) => (
                  <button
                    key={group.label}
                    type="button"
                    role="tab"
                    aria-selected={activeSkill === index}
                    aria-controls="skill-panel"
                    className={`skill-tab${activeSkill === index ? ' active' : ''}`}
                    onClick={() => setActiveSkill(index)}
                    data-testid={`button-skill-${index}`}
                  >
                    {group.label}<span>{group.count}</span>
                  </button>
                ))}
              </div>
              <div className="skill-content" id="skill-panel" role="tabpanel" aria-live="polite">
                <h3>{skillGroups[activeSkill].title}</h3>
                <p>{skillGroups[activeSkill].description}</p>
                <div className="skill-chips">
                  {skillGroups[activeSkill].examples.map((example) => <span className="chip" key={example}>{example}</span>)}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="projects" aria-labelledby="projects-title">
          <div className="container">
            <div className="section-heading">
              <div><div className="eyebrow">03 / The workbench</div><h2 className="section-title display" id="projects-title">Ideas to make real.</h2></div>
              <p className="section-intro">A project list should grow from things actually built. These are prompts to customize—not completed projects.</p>
            </div>
            <div className="projects-topline">
              <div className="filters" role="group" aria-label="Filter project examples">
                {['All', 'AI / ML', 'Web'].map((category) => (
                  <button
                    key={category}
                    type="button"
                    className={`filter${filter === category ? ' active' : ''}`}
                    onClick={() => setFilter(category)}
                    aria-pressed={filter === category}
                    data-testid={`button-filter-${category.toLowerCase().replace(/[^a-z]+/g, '-')}`}
                  >{category}</button>
                ))}
              </div>
              <span className="project-disclaimer">Suggested examples · verify, build, and customize before publishing</span>
            </div>
            <div className="project-grid" aria-live="polite">
              {visibleProjects.map((project, index) => (
                <article className="project-card" key={project.title} data-testid={`card-project-${index}`}>
                  <div className="project-meta"><span className="project-index">IDEA / 0{projects.indexOf(project) + 1}</span><span className="project-status">Example only</span></div>
                  <div className="project-preview" role="img" aria-label={`Screenshot placeholder: ${project.preview}`}>
                    <div className="preview-window">
                      <div className="preview-window-bar"><span /><span /><span /><small>PROJECT PREVIEW</small></div>
                      <div className="preview-placeholder">
                        <Code2 size={20} aria-hidden="true" />
                        <span>{project.preview}</span>
                        <small>Screenshot placeholder</small>
                      </div>
                    </div>
                  </div>
                  <h3>{project.title}</h3>
                  <p>{project.summary}</p>
                  <div className="project-bottom">
                    <span className="project-stack-label">Possible technologies · verify</span>
                    <div className="project-tech">{project.stack.map((item) => <span key={item}>{item}</span>)}</div>
                    <div className="project-links" aria-label="Project links not supplied">
                      <span>GitHub URL not added</span>
                      <span>Live demo not added</span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="journey" aria-labelledby="journey-title">
          <div className="container">
            <div className="section-heading">
              <div><div className="eyebrow">04 / The path so far</div><h2 className="section-title display" id="journey-title">A foundation in progress.</h2></div>
              <p className="section-intro">The meaningful parts of a journey are worth documenting accurately—even when the timeline is just getting started.</p>
            </div>
            <div className="timeline" aria-label="Education">
              <article className="timeline-item">
                <div className="timeline-date">CURRENT · YEAR 2</div>
                <div>
                  <h3>B.Tech, Computer Science and Engineering</h3>
                  <p className="timeline-sub">Specialization: Artificial Intelligence and Machine Learning</p>
                  <p>Sandip University · Nashik, Maharashtra, India</p>
                </div>
              </article>
            </div>
            <div style={{ height: 34 }} />
            <div className="credential-list">
              <article className="credential">
                <div className="eyebrow"><Award size={12} style={{ verticalAlign: 'middle', marginRight: 6 }} />Achievements</div>
                <h3>Room for the next milestone</h3>
                <p>Add verified awards, academic milestones, or other achievements here. Include the date and issuing organization.</p>
                <span className="placeholder-label">No achievement details added yet</span>
              </article>
              <article className="credential">
                <div className="eyebrow"><BookOpen size={12} style={{ verticalAlign: 'middle', marginRight: 6 }} />Certifications</div>
                <h3>Learning, documented</h3>
                <p>Add a certification only after it is earned. Name the provider, credential, date, and a public verification link if available.</p>
                <span className="placeholder-label">No certifications added yet</span>
              </article>
            </div>
          </div>
        </section>

        <section className="section" id="experience" aria-labelledby="experience-title">
          <div className="container">
            <div className="section-heading">
              <div><div className="eyebrow">05 / Experience</div><h2 className="section-title display" id="experience-title">Space for what’s next.</h2></div>
              <BriefcaseBusiness size={22} style={{ color: 'hsl(var(--muted-foreground))' }} aria-hidden="true" />
            </div>
            <div className="experience-empty">
              <strong>Early-career, and building momentum.</strong>
              No work or internship experience has been provided yet. Add a role here when there is a real position, organization, date range, and contribution to share.
            </div>
          </div>
        </section>

        <section className="section" id="resume" aria-labelledby="resume-title">
          <div className="container">
            <div className="resume-panel">
              <div>
                <div className="eyebrow">06 / Resume</div>
                <h3 id="resume-title">A proper resume is on the way.</h3>
                <p>There isn’t a resume file in this project yet. Add your verified PDF at <span className="mono">public/assets/resume.pdf</span> before enabling a download.</p>
              </div>
              <button className="button disabled" type="button" disabled aria-disabled="true" title="Unavailable until public/assets/resume.pdf is supplied" data-testid="button-resume-unavailable">
                <Download size={15} /> Not available yet
              </button>
            </div>
          </div>
        </section>

        <section className="section" id="contact" aria-labelledby="contact-title">
          <div className="container contact-layout">
            <div>
              <div className="eyebrow">07 / Get in touch</div>
              <h2 id="contact-title">Let’s start a real conversation.</h2>
              <p className="lead">Interested in learning together, sharing project feedback, or saying hello? Add a contact channel you actively use and are comfortable sharing publicly.</p>
            </div>
            <div className="contact-box">
              <h3>Contact details to add</h3>
              <p>No email address or social profiles were supplied, so there are no placeholder links that could lead somewhere unexpected.</p>
              <div className="contact-placeholder"><Mail size={17} /><span>Replace with a verified public email address</span></div>
              <div className="contact-placeholder" style={{ marginTop: 9 }}><Code2 size={17} /><span>Add real GitHub / LinkedIn URLs when ready</span></div>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-inner">
          <div className="footer-main">
            <span className="footer-mark">Mayur Jadhav <span style={{ color: 'hsl(var(--muted-foreground))', fontWeight: 400 }}>· still learning</span></span>
            <nav className="footer-nav" aria-label="Footer navigation">
              {[...navigation, ['Experience', '#experience'], ['Resume', '#resume']].map(([label, href]) => <a href={href} key={href}>{label}</a>)}
            </nav>
          </div>
          <div className="footer-bottom">
            <div className="footer-social" aria-label="Social profile placeholders">
              <span>GitHub <small>add profile URL</small></span>
              <span>LinkedIn <small>add profile URL</small></span>
            </div>
            <span>Made as a snapshot, not a finished story.</span>
            <a className="to-top" href="#top">Back to top <ArrowUp size={13} /></a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
